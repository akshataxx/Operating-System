 Akshata Dhuraji, c3309266
 Operating System Assignment2 - P1, P2, P3
 Instruction : Each problem code to be stored in the same package/folder at the runtime. Example the 3 .java files under folder 1 to be stored in the same pacakage. 